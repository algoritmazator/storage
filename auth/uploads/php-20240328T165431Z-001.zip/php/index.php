<?php

echo " <a href='/form.html'> ссылка на форму </a>";




?>