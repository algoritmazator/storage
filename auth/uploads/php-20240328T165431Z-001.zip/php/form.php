<?php
// echo $_FILES['filename']['size'] . '<br>'; // размер в байтах
// echo $_FILES['filename']['name'] . '<br>'; // выводим имя файла
// echo $_FILES['filename']['tmp_name'];

// 1kb = 1024b и 1mb = 1024kb // 2 * 1024 * 1024

if(move_uploaded_file($_FILES['filename']['tmp_name'], 'temp/'.$_FILES['filename']['name'])){
	if ($_FILES['filename']['size'] > 1*1024*1024) {
		echo 'Размер файла превышает 2 мегабайта';
		exit();
		echo 'test';
	}else{
		echo 'Файл скопирован на сервер<br>';
		echo 'Характеристики нашего файла:<br>';
		echo 'Имя файла: ';
		echo $_FILES['filename']['name'] . '<br>';
		echo 'Размер файла: ';
		echo $_FILES['filename']['size'] . '<br>';
		echo 'Тип файла: ';
		echo $_FILES['filename']['type'] . '<br>';
	} 
}
?>